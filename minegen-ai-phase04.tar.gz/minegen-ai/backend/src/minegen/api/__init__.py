"""MineGen-AI subpackage."""
